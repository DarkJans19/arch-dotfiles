﻿=== Miku Hatsune Cursor Set ===

By: ツ☪ NaLexnu ♡♥ (http://www.rw-designer.com/user/38152) mlopez1662@hotmail.com

Download: http://www.rw-designer.com/cursor-set/miku-hatsune-md

Author's description:

ツ NaLexnu ♥.♡  
Credits to Miku Hatsune and others
http://mimidestino.deviantart.com/art/Cursores-de-Miku-Hatsune-Cursors-Punteros-674908843

--

How to install?
https://youtu.be/VOr3HZHS4fQ

Como instalarlos?
https://youtu.be/EGx6plXI0Yc

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.